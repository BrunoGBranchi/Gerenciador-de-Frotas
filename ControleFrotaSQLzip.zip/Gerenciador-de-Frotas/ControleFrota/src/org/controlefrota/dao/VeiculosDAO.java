package org.controlefrota.dao;

import org.controlefrota.dao.CrudDAO;
import org.controlefrota.model.t_Veiculos;

public interface VeiculosDAO  extends CrudDAO<t_Veiculos>{
	
}
