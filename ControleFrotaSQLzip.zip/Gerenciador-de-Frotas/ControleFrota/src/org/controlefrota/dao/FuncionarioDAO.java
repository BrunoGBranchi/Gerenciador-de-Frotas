package org.controlefrota.dao;

import org.controlefrota.dao.CrudDAO;
import org.controlefrota.model.Funcionarios;

public interface FuncionarioDAO extends CrudDAO<Funcionarios> {

}
