package org.controlefrota.dao;

import org.controlefrota.model.Movimentos;

public interface MovimentosDAO extends CrudDAO<Movimentos> {

}
