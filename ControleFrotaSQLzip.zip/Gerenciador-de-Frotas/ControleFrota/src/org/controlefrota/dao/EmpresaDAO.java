package org.controlefrota.dao;

import org.controlefrota.model.Empresa;

public interface EmpresaDAO extends CrudDAO<Empresa>{

}
