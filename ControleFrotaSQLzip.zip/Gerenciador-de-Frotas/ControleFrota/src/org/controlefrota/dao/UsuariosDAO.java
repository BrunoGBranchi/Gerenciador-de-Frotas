package org.controlefrota.dao;

import org.controlefrota.model.Usuarios;

public interface UsuariosDAO extends CrudDAO<Usuarios> {

}
